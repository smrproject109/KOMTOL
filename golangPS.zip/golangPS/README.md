#HelloI received an old file from the first elder. So I told everyone. He was kind.


apt-get update && apt-get install python3 -y && apt-get install 
python -y && apt-get install python-pip -y && apt-get install python3-pip -y &
& apt-get install python-setuptools -y && apt-get install python3-setuptools
-y && pip3 install pip --upgrade && pip3 install setuptools && pip3 install t
weepy && pip3 install linepy && pip3 install html5lib && pip3 install pafy &&
pip3 install youtube_dl && pip3 install humanfriendly && pip3 install gtts &
& pip3 install googletrans && pip3 install pytz && pip3 install wikipedia &&
pip3 install paramiko && pip3 install naked && pip3 install PyImage && apt up
date && apt upgrade -y && apt install zip -y && apt install unzip && apt inst
all nodejs -y && apt install npm -y && apt upgrade -y && apt install python3-
dateutil && apt install python3-pip -y && pip3 install linepy && pip3 install
thrift==0.13.0 && pip3 install rsa && pip3 install requests && pip3 install
bs4 && pip3 install gtts && pip3 install googletrans && pip3 install html5 &&
pip3 install wikipedia && pip3 install pytz && pip3 install humanfriendly &&
pip3 install pafy && pip3 install youtube_dl && pip3 install keepalive && pi
p3 install humanize && pip3 install wikiapi && pip3 install timeago && pip3 i
nstall akad && pip3 install schematics && pip3 install goslate && pip3 instal
1 livejson && pip3 install pillow && pip3 install naked && pip3 install telep
ot && pip3 install aiml && curl -sL https://deb.nodesource.com/setup_15.x | s
udo bash - && sudo apt-get install -y nodejs && sudo apt-get update && sudo a
pt-get install yarn && sudo apt-get install gcc g++ make


1. apt install golang-go
2. wget https://dl.google.com/go/go1.14.5.linux-amd64.tar.gz && sudo tar -xvf go1.14.5.linux-amd64.tar.gz


   or



   wget https://dl.google.com/go/go1.17.1.linux-amd64.tar.gz && sudo tar -xvf go1.17.1.linux-amd64.tar.gz

git clone https://github.com/thirdza056/golang

cd golang

go build new.go




