import os, time

botStart = time.time()
try:os.system('./main a1 & ./main a2 & ./main a3 & ./main a4')
except:pass
